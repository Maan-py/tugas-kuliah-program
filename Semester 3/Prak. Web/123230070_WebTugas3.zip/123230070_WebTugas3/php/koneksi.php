<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "tugas3";

$connect = new mysqli($hostname, $username, $password, $database);
